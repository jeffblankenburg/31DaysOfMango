﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Expression.Blend.SampleData.Furniture;
using Microsoft.Phone.Tasks;

namespace Day18_BlendSampleData
{
    public partial class MainPage : PhoneApplicationPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

		private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			ChairsItem ci = e.AddedItems[0] as ChairsItem;
			string URL = ci.Price;
			WebBrowserTask wbt = new WebBrowserTask();
			wbt.Uri = new Uri(URL);
			wbt.Show();
		}
    }
}
