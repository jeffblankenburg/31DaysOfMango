﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Xna.Framework.Media;

namespace _31DaysMediaLibrary
{
	public static class MediaLibraryHelpers
	{
		public static void SaveResourceImageToLibrary(string imageName)
		{
			var library = new MediaLibrary();
			var image = library.Pictures.Where(p => p.Name == imageName).SingleOrDefault();

			if (image == null)
			{
				var resource = 
					Application
					.GetResourceStream(new Uri(string.Format("/31DaysMediaLibrary;component/Images/{0}", 
											   imageName), 
									   UriKind.Relative));
				var bitmap = new BitmapImage();
				bitmap.SetSource(resource.Stream);

				// Save the image to the camera roll or saved pictures album.
				library.SavePicture(imageName, bitmap.ToStream());
			}			
		}		
	}
}
