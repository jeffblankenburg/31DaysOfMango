﻿using System;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Media;

namespace _31DaysMediaLibrary
{
	public partial class MainPage : PhoneApplicationPage
	{
		private PhotoChooserTask _photoChooser;
		
		public MainPage()
		{
			InitializeComponent();
			var library = new MediaLibrary();
			lstSongs.ItemsSource = library.Songs;		
			_photoChooser = new PhotoChooserTask();
			_photoChooser.Completed +=PhotoChooserCompleted;

			//NOTE: We are using XNA in here to get access to the MediaPlayer. 
			//Because of that we need to triger the FrameworkDispatcher.Update. 
			var timer = new DispatcherTimer { Interval = TimeSpan.FromTicks(333333) };
			timer.Tick += delegate { try { FrameworkDispatcher.Update(); } catch { } }; timer.Start();
		}
		
		private void PhotoChooserCompleted(object sender, PhotoResult e)
		{
			if (e.ChosenPhoto == null)
			{
				return;
			}

			var bitmap = new BitmapImage();
			bitmap.SetSource(e.ChosenPhoto);

			SetBackground(bitmap);
		}
		
		private void ChooseBackgroundClick(object sender, EventArgs e)
		{
			_photoChooser.Show();
		}

		private void SongSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			MediaPlayer.Play((Song) lstSongs.SelectedItem);
		}

		private void SetBackground(BitmapImage image)
		{
			var brush = new ImageBrush
			{
				ImageSource = image,
				Stretch = Stretch.UniformToFill,
				Opacity = .7
			};

			LayoutRoot.Background = brush;
		}
	}
}