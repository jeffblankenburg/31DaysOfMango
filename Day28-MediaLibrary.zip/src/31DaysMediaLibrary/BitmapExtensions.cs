﻿using System.IO;
using System.Windows.Media.Imaging;

namespace _31DaysMediaLibrary
{
	public static class BitmapExtensions
	{
		public static Stream ToStream(this BitmapImage bitmap)
		{
			var writeableBitmap = new WriteableBitmap(bitmap);
			var stream = new MemoryStream();
			writeableBitmap.SaveJpeg(stream, bitmap.PixelWidth, bitmap.PixelHeight, 0, 100);
			stream.Position = 0;
			return stream;
		}
	}
}
