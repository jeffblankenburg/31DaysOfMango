﻿using System;
using Microsoft.Phone.Controls;
using Microsoft.Devices.Sensors;
using Microsoft.Xna.Framework;

namespace Day5_Gyroscope
{
	public partial class MainPage : PhoneApplicationPage
	{
		Gyroscope g;
		
		public MainPage()
		{
			InitializeComponent();

			if (Gyroscope.IsSupported)
			{
				g = new Gyroscope();
				g.TimeBetweenUpdates = TimeSpan.FromMilliseconds(20);
				g.CurrentValueChanged += new EventHandler<SensorReadingEventArgs<GyroscopeReading>>(g_CurrentValueChanged);
				g.Start();
			}
			else statusTextBlock.Text = "gyroscope not supported";
		}

		void g_CurrentValueChanged(object sender, SensorReadingEventArgs<GyroscopeReading> e)
		{
			Dispatcher.BeginInvoke(() => UpdateUI(e.SensorReading));
		}

		private void UpdateUI(GyroscopeReading gyroscopeReading)
		{
			statusTextBlock.Text = "getting data";
			Vector3 rotationReading = gyroscopeReading.RotationRate;

			xTextBlock.Text = "X " + rotationReading.X.ToString("0.00");
			yTextBlock.Text = "Y " + rotationReading.Y.ToString("0.00");
			zTextBlock.Text = "Z " + rotationReading.Z.ToString("0.00");

			xLine.X2 = xLine.X1 + rotationReading.X * 200;
			yLine.Y2 = yLine.Y1 - rotationReading.Y * 200;
			zLine.X2 = zLine.X1 - rotationReading.Z * 100;
			zLine.Y2 = zLine.Y1 + rotationReading.Z * 100;
		}
	}
}
