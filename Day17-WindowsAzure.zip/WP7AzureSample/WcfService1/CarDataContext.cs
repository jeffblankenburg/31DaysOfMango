﻿using System.Linq;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using WcfService1.Entities;

namespace WcfService1
{
    public class CarDataContext : TableServiceContext
    {
        public const string EntitySetName = "Cars";

        public CarDataContext(string baseAddress, StorageCredentials credentials) 
            : base(baseAddress, credentials)
        {
        }

        public IQueryable<Car> Cars
        {
            get
            {
                return CreateQuery<Car>(EntitySetName);
            }
        }
    }
}