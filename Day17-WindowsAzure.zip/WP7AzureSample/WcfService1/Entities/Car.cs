﻿using System;
using Microsoft.WindowsAzure.StorageClient;

namespace WcfService1.Entities
{
    public sealed class Car : TableServiceEntity
    {
        /*
         * PartitionKey = make
         * RowKey = current date/time in UTC
         */

        public Car()
        {}

        public Car(string make, string model, int year, string description, string imageUrl)
        {
            PartitionKey = make;
            RowKey = DateTime.UtcNow.Ticks.ToString();

            Make = make;
            Model = model;
            Year = year;
            Description = description;
            ImageUrl = imageUrl;
        }

        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
    }
}