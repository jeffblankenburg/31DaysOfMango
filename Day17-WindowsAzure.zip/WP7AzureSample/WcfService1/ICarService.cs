﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Web;
using WcfService1.Entities;

namespace WcfService1
{
    [ServiceContract]
    public interface ICarService
    {
        [OperationContract]
        [WebInvoke(UriTemplate = "/car", 
            BodyStyle = WebMessageBodyStyle.Bare, 
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json, 
            Method = "POST")]
        void AddCar(Car car);

        [OperationContract]
        [WebGet(UriTemplate = "/car/sas", 
            BodyStyle = WebMessageBodyStyle.Bare,
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json)]
        Uri CreateCarImageSharedAccessSignature();
        
        [OperationContract]
        [WebGet(UriTemplate = "/cars", 
            BodyStyle = WebMessageBodyStyle.Bare,
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json)]
        IList<CarModel> ListAllCars();
    }
}
