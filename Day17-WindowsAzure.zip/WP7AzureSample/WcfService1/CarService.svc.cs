﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Web;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.StorageClient;
using WcfService1.Entities;

namespace WcfService1
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class CarService : ICarService
    {
        public void AddCar(Car car)
        {
            try
            {
                var key = ValidateApplicationKey();
                if (key)
                {
                    var carDataSource = new CarDataSource();
                    carDataSource.CreateCar(car);
                }
            }
            catch (Exception)
            {
                throw new WebFaultException<string>("Failed to create a new car.", HttpStatusCode.InternalServerError);
            }
        }

        [AspNetCacheProfile("ListCars")]
        public IList<CarModel> ListAllCars()
        {
            var key = ValidateApplicationKey();
            if (key)
            {
                var carDataSource = new CarDataSource();
                var cars = carDataSource.GetAllCars();
                return (from c in cars
                        select
                            new CarModel
                            {
                                Make = c.Make,
                                Description = c.Description,
                                ImageUrl = c.ImageUrl,
                                Model = c.Model,
                                PartitionKey = c.PartitionKey,
                                RowKey = c.RowKey
                            }).ToList();
            }

            return null;
        }

        public Uri CreateCarImageSharedAccessSignature()
        {
            Uri signatureUri = null;

            var key = ValidateApplicationKey();
            if (key)
            {
                try
                {
                    CloudBlobContainer container = CreateContainer("cars");

                    // Set permissions on the container.
                    var sas = container.GetSharedAccessSignature(
                        new SharedAccessPolicy
                            {
                                Permissions =
                                    SharedAccessPermissions.Write |
                                    SharedAccessPermissions.List,
                                SharedAccessStartTime = DateTime.UtcNow,
                                SharedAccessExpiryTime = DateTime.UtcNow + TimeSpan.FromMinutes(5)
                            });

                    // Trim the leading '?' to prevent there from being two in the resulting URI.
                    var uriBuilder = new UriBuilder(container.Uri) {Query = sas.TrimStart('?')};
                    signatureUri = uriBuilder.Uri;
                }
                catch (Exception ex)
                {
                    throw new WebFaultException<string>(ex.Message, HttpStatusCode.InternalServerError);
                }
            }

            return signatureUri;
        }

        private CloudBlobContainer CreateContainer(string containerName)
        {
            string connectionString = RoleEnvironment.IsAvailable ? 
                                        RoleEnvironment.GetConfigurationSettingValue("DataConnectionString") : 
                                        ConfigurationManager.AppSettings["DataConnectionString"];

            var storageAccount = CloudStorageAccount.Parse(connectionString);

            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);

            container.CreateIfNotExist();

            // Create each container with read access for blobs - so everybody can see the pictures you take
            // if they know the URL.
            var permissions = new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob };
            container.SetPermissions(permissions);

            return container;
        }

        private bool ValidateApplicationKey()
        {
            string serviceApiKey = RoleEnvironment.IsAvailable ?
                                    RoleEnvironment.GetConfigurationSettingValue("ServiceApiKey") :
                                    ConfigurationManager.AppSettings["ServiceApiKey"];

            bool isValid = false;

            if (WebOperationContext.Current != null)
            {
                var key = WebOperationContext.Current.IncomingRequest.Headers["ApplicationKey"];

                if (string.IsNullOrEmpty(key))
                {
                    throw new ApplicationException("Required application authentication key was not supplied.");
                }

                if (key.Equals(serviceApiKey, StringComparison.InvariantCulture))
                {
                    isValid = true;
                }
            }

            return isValid;
        }
    }
}
