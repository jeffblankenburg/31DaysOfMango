﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using WcfService1.Entities;
using Microsoft.WindowsAzure.StorageClient;

namespace WcfService1
{
    public interface ICarDataSource
    {
        void CreateCar(Car car);
        IEnumerable<Car> GetAllCars();
    }

    public class CarDataSource : ICarDataSource
    {
        private static readonly CloudStorageAccount storageAccount;
        private readonly CarDataContext dataContext;

        static CarDataSource()
        {
            // Retrieve the connection string from the ServiceConfiguration.cscfg file.
            string connectionString = RoleEnvironment.IsAvailable ? 
                                        RoleEnvironment.GetConfigurationSettingValue("DataConnectionString") : 
                                        ConfigurationManager.AppSettings["DataConnectionString"];
            
            storageAccount = CloudStorageAccount.Parse(connectionString);
        }

        public CarDataSource()
        {
            dataContext = new CarDataContext(storageAccount.TableEndpoint.AbsoluteUri, storageAccount.Credentials)
            {
                RetryPolicy = RetryPolicies.Retry(5, TimeSpan.FromSeconds(1))
            };
        }

        public void CreateCar(Car car)
        {
            if (car != null)
            {
                dataContext.AddObject(CarDataContext.EntitySetName, car);
                dataContext.SaveChangesWithRetries();
            }
        }

        public IEnumerable<Car> GetAllCars()
        {
            var cars = (from c in dataContext.Cars select c).AsTableServiceQuery();
            return cars;
        }
    }
}