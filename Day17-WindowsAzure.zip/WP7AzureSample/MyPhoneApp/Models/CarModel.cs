﻿
using System.Runtime.Serialization;

namespace MyPhoneApp.Models
{
    [DataContract]
    public class CarModel
    {
        [DataMember]
        public string PartitionKey { get; set; }

        [DataMember]
        public string RowKey { get; set; }

        [DataMember]
        public string Make { get; set; }

        [DataMember]
        public string Model { get; set; }

        [DataMember]
        public int Year { get; set; }

        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public string ImageUrl { get; set; }
    }
}
