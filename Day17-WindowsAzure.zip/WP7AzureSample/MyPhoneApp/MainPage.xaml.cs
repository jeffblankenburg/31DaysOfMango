﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.WindowsAzure.Samples.Phone.Identity.AccessControl;

namespace MyPhoneApp
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            SimpleWebTokenStore simpleWebTokenStore = Application.Current.Resources["swtStore"] as SimpleWebTokenStore;
            var name = simpleWebTokenStore.SimpleWebToken.Claims[ClaimTypes.Name];
            var emailAddress = simpleWebTokenStore.SimpleWebToken.Claims[ClaimTypes.Email];

            CurrentUser.Text = string.Format("Welcome {0} ({1})!", name, emailAddress);
        }

        private void AddCarButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/NewCarPage.xaml", UriKind.Relative));
        }

        private void ListCarsButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/CarsPage.xaml", UriKind.Relative));
        }

        private void ApplicationBarMenuItemLogoutClick(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to log out?", "Log out", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                SimpleWebTokenStore simpleWebTokenStore = Application.Current.Resources["swtStore"] as SimpleWebTokenStore;
                simpleWebTokenStore.SimpleWebToken = null;
                NavigationService.Navigate(new Uri("/Pages/LoginPage.xaml", UriKind.Relative));
            }
        }
    }
}