﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;
using PhoneApp2.ViewModel;

namespace MyPhoneApp.Pages
{
    public partial class NewCarPage : PhoneApplicationPage
    {
        public NewCarPage()
        {
            InitializeComponent();

            ViewModel = new NewCarViewModel();
        }

        public NewCarViewModel ViewModel
        {
            get { return this.DataContext as NewCarViewModel; }
            set { this.DataContext = value; }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            ViewModel.Save();
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void OnAppMenuItemTakePictureClick(object sender, EventArgs e)
        {
            CameraCaptureTask task = new CameraCaptureTask();
            task.Completed += OnCameraCaptureTaskCompleted;
            task.Show();
        }

        private void OnCameraCaptureTaskCompleted(object sender, PhotoResult e)
        {
            if (e.TaskResult == TaskResult.OK)
            {
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.SetSource(e.ChosenPhoto);
                carImage.Source = bitmapImage;

                ViewModel.SavePictureToPhone(e);
            }
        }
    }
}