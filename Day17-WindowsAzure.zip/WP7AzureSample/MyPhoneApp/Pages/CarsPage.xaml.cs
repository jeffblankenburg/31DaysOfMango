﻿using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Net.NetworkInformation;
using MyPhoneApp.ViewModel;

namespace MyPhoneApp.Pages
{
    public partial class CarsPage : PhoneApplicationPage
    {
        public CarsPage()
        {
            InitializeComponent();

            ViewModel = new CarListViewModel();

            Loaded += OnPageLoaded;
        }

        private void OnPageLoaded(object sender, RoutedEventArgs e)
        {
            if (NetworkInterface.GetIsNetworkAvailable())
            {
                if (this.ViewModel != null)
                {
                    this.ViewModel.ListCars();
                }
            }
        }

        public CarListViewModel ViewModel
        {
            get { return this.DataContext as CarListViewModel; }
            set { this.DataContext = value; }
        }
    }
}