﻿using System;
using System.IO;
using System.Net;
using System.Net.Browser;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Phone.Shell;
using Microsoft.Phone.Tasks;
using MyPhoneApp;
using MyPhoneApp.Models;
using MyPhoneApp.ViewModel;

namespace PhoneApp2.ViewModel
{
    public class NewCarViewModel : BaseViewModel
    {
        private string make;
        private string model;
        private string description;
        private int year;

        private const string PhotoResultKey = "PhotoResult";
        private readonly Dispatcher dispatcher;

        private event EventHandler<SharedAccessSignatureEventArgs> SharedAccessSignatureCompleted;
        private event EventHandler<ImageSaveCompletedEventArgs> ImageSaveCompleted;

        public NewCarViewModel()
        {
            dispatcher = Deployment.Current.Dispatcher;
            SharedAccessSignatureCompleted += OnSharedAccessSignatureCompleted;
            ImageSaveCompleted += NewImageSaveCompleted;
        }

        #region Properties
        
        public string Make
        {
            get { return this.make; }
            set
            {
                if (this.make != value)
                {
                    make = value;
                    NotififyPropertyChanged("Make");
                }
            }
        }

        public string Model
        {
            get { return this.model; }
            set
            {
                if (this.model != value)
                {
                    model = value;
                    NotififyPropertyChanged("Model");
                }
            }
        }

        public string Description
        {
            get { return this.description; }
            set
            {
                if (this.description != value)
                {
                    description = value;
                    NotififyPropertyChanged("Description");
                }
            }
        }

        public int Year
        {
            get { return this.year; }
            set
            {
                if (this.year != value)
                {
                    year = value;
                    NotififyPropertyChanged("Year");
                }
            }
        }

        #endregion

        private void SavePicture(string url)
        {
            PhotoResult photoResult = null;
            if (PhoneApplicationService.Current.State.ContainsKey("PhotoResult"))
            {
                var result = PhoneApplicationService.Current.State["PhotoResult"];
                photoResult = result as PhotoResult;
            }

            if (photoResult != null)
            {
                Uri imageUri = new Uri(url);
                string blobName = string.Format("Car-{0}{1}",
                                                DateTime.UtcNow.ToString("yyyyMMddTHHmmss"),
                                                System.IO.Path.GetExtension(photoResult.OriginalFileName));
                string sas = imageUri.Query;

                // Get everything up to the '?'
                string baseUri = imageUri.ToString().Substring(0, imageUri.ToString().IndexOf('?'));

                // Create the full URI to PUT the image to in BLOB storage.
                string fullUri = string.Format("{0}/{1}{2}", baseUri, blobName, sas);

                // Create the URI for the BLOB, but without the Shared Access Signature.
                string blobAddress = string.Format("{0}/{1}", baseUri, blobName);

                // NOTE: Post full URI (SAS applies to blob). See http://msdn.microsoft.com/en-us/library/ee395415.aspx
                var client = WebRequest.Create(fullUri) as HttpWebRequest;

                if (client != null)
                {
                    client.ContentType = "image/jpeg";
                    client.Method = "PUT";

                    var byteArray = new byte[photoResult.ChosenPhoto.Length];
                    photoResult.ChosenPhoto.Position = 0;
                    photoResult.ChosenPhoto.Read(byteArray, 0, byteArray.Length);
                    photoResult.ChosenPhoto.Close();

                    client.BeginGetRequestStream(callback =>
                    {
                        var postStream = client.EndGetRequestStream(callback);
                        postStream.Write(byteArray, 0, byteArray.Length);
                        postStream.Close();

                        client.BeginGetResponse(result =>
                        {
                            try
                            {
                                // Response should be empty if everything worked OK.
                                var response = client.EndGetResponse(result);
                                OnImageSaved(blobAddress);
                            }
                            catch (Exception ex)
                            {
                                var webEx = ex as WebException;
                                if (webEx != null)
                                {
                                    var errorText = new StreamReader(webEx.Response.GetResponseStream()).ReadToEnd();

                                    // TODO: Add error handling.
                                }
                            }
                        }, null);
                    }, null);
                }
            }
        }

        public void Save()
        {
            if (DoesPictureExist())
            {
                // Get shared access signature
                GetSharedAccessSignature();
            }
            else
            {
                PostNewCar(string.Empty);
            }
        }

        private void GetSharedAccessSignature()
        {
            var webClient = new WebClient();
            webClient.Headers["ApplicationKey"] = App.ResolveCarServiceApiKey();

            UriBuilder uriBuilder = new UriBuilder(App.ResolveCarService());
            uriBuilder.Path += "/car/sas";

            webClient.DownloadStringCompleted += (sender, args) =>
            {
                if (args.Error != null) return;

                string uriString = null;
                using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(args.Result)))
                {
                    var serializer = new DataContractJsonSerializer(typeof (string));
                    uriString = serializer.ReadObject(ms) as string;
                }

                OnSharedAccessSignatureCompleted(this, new SharedAccessSignatureEventArgs{Url = uriString});
            };

            webClient.DownloadStringAsync(uriBuilder.Uri);
        }

        private void PostNewCar(string imageUrl)
        {
            var clientHttp = WebRequestCreator.ClientHttp;

            UriBuilder uriBuilder = new UriBuilder(App.ResolveCarService());
            uriBuilder.Path += "/car";

            var request = clientHttp.Create(uriBuilder.Uri);
            request.Headers["ApplicationKey"] = App.ResolveCarServiceApiKey();
            request.ContentType = "application/json";
            request.Method = "POST";

            var car = new CarModel
                          {
                              PartitionKey = this.year.ToString(),
                              RowKey = DateTime.UtcNow.Ticks.ToString(),
                              Make = this.make, 
                              Model = this.model,
                              Year = this.year,
                              Description = this.description,
                              ImageUrl = imageUrl ?? string.Empty
                          };

            string postData = string.Empty;
            using (var stream = new MemoryStream())
            {
                var serializer = new DataContractJsonSerializer(typeof (CarModel));
                serializer.WriteObject(stream, car);
                byte[] bytes = stream.ToArray();
                postData = Encoding.Unicode.GetString(bytes, 0, bytes.Length);
            }

            request.BeginGetRequestStream(
                callback =>
                    {
                        var postStream = request.EndGetRequestStream(callback);
                        var byteArray = Encoding.Unicode.GetBytes(postData);
                        postStream.Write(byteArray, 0, byteArray.Length);
                        postStream.Close();

                        request.BeginGetResponse(
                            asyncResult =>
                                {
                                    var msg = string.Empty;
                                    try
                                    {
                                        var response = request.EndGetResponse(asyncResult);
                                        msg = new StreamReader(response.GetResponseStream()).ReadToEnd();
                                        if (string.IsNullOrEmpty(msg))
                                        {
                                            // TODO: Success - add appropriate next step.
                                        }
                                        else
                                        {
                                            // TODO: Something went wrong.  Add appropriate logic.
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        var webEx = ex as WebException;
                                        if (webEx != null)
                                        {
                                            var errorText = new StreamReader(webEx.Response.GetResponseStream()).ReadToEnd();
                                        }
                                    }
                                }, null);
                    }, request);
        }

        private bool DoesPictureExist()
        {
            return PhoneApplicationService.Current.State.ContainsKey(PhotoResultKey);
        }

        public void SavePictureToPhone(PhotoResult photoResult)
        {
            if (PhoneApplicationService.Current.State.ContainsKey(PhotoResultKey))
            {
                PhoneApplicationService.Current.State.Remove(PhotoResultKey);
            }

            PhoneApplicationService.Current.State.Add(PhotoResultKey, photoResult);
        }

        #region Event Handlers

        void NewImageSaveCompleted(object sender, ImageSaveCompletedEventArgs e)
        {
            dispatcher.BeginInvoke(() => PostNewCar(e.ImageAddress));
        }

        void OnSharedAccessSignatureCompleted(object sender, SharedAccessSignatureEventArgs e)
        {
            if (!string.IsNullOrEmpty(e.Url))
            {
                // Save the picture
                SavePicture(e.Url);
            }
        }

        private void OnImageSaved(string imageAddress)
        {
            if (ImageSaveCompleted != null)
                ImageSaveCompleted(this, new ImageSaveCompletedEventArgs { ImageAddress = imageAddress });
        }

        #endregion
    }

    internal class ImageSaveCompletedEventArgs : EventArgs
    {
        public string ImageAddress { get; set; }
    }

    internal class SharedAccessSignatureEventArgs : EventArgs
    {
        public string Url { get; set; }
    }
}
