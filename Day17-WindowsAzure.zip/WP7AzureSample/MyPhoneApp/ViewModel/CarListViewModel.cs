﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Windows;
using System.Windows.Threading;
using MyPhoneApp.Models;

namespace MyPhoneApp.ViewModel
{
    public class CarListViewModel : BaseViewModel
    {
        private readonly Dispatcher dispatcher;
        public ObservableCollection<CarModel> Cars { get; set; }

        public CarListViewModel()
        {
            dispatcher = Deployment.Current.Dispatcher;
            Cars = new ObservableCollection<CarModel>();
        }

        public void ListCars()
        {
            var webClient = new WebClient();
            webClient.Headers["ApplicationKey"] = App.ResolveCarServiceApiKey();
            webClient.DownloadStringCompleted += ListCarCompleted;

            UriBuilder uriBuilder = new UriBuilder(App.ResolveCarService());
            uriBuilder.Path += "/cars";

            webClient.DownloadStringAsync(uriBuilder.Uri);
        }

        void ListCarCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            if (e.Error != null) return;

            IList<CarModel> cars = null;

            var serializer = new DataContractJsonSerializer(typeof(List<CarModel>));
            using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(e.Result)))
            {
                cars = serializer.ReadObject(ms) as List<CarModel>;
            }

            if (cars == null) return;

            foreach (CarModel car in cars)
            {
                Cars.Add(car);
            }
        }
    }
}
