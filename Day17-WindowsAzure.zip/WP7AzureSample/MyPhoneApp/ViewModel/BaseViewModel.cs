﻿using System.ComponentModel;

namespace MyPhoneApp.ViewModel
{
    public class BaseViewModel : INotifyPropertyChanged
    {
        private bool waiting;
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void NotififyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public bool IsWaiting
        {
            get { return waiting; }
            set
            {
                if (waiting != value)
                {
                    waiting = value;
                    NotififyPropertyChanged("IsWaiting");
                }
            }
        }
    }
}
