﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace TakeMyOrder
{
    public partial class MainPage : PhoneApplicationPage
    {
        //Server name
        string serverName="First Last" + (new Random()).Next(100).ToString();
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            ApplicationTitle.Text = ApplicationTitle.Text+  " Server: " + serverName;
            //Send command to join the multi cast group
            App.Order.Join(serverName);
            //Wire up an event to process incoming messages for order status
            App.Order.DataReceivedFromDevice += new DataReceivedFromDeviceEventHandler(Order_DataReceivedFromDevice);
      
        }

        /// <summary>
        /// Shows a message box with the order status
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Order_DataReceivedFromDevice(object sender, OrderStatusReceivedEventArgs e)
        {
            DiagnosticsHelper.SafeShow("Order Status of '" +e.orderStatus + "' Received For Order:" + e.orderId.ToString());
        }

        /// <summary>
        /// Rounds the slider value so we get whole numbers
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TableSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (TableSlider != null)
            {
                TableSlider.Value = Math.Round(e.NewValue);
            }
        }

        /// <summary>
        /// Rounds the slider value so we get whole numbers
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void spiceSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (spiceSlider != null)
            {
                spiceSlider.Value = Math.Round(e.NewValue);
            }
        }

        /// <summary>
        /// Sends the order
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOrder_Click(object sender, RoutedEventArgs e)
        {
            //Send order to the wpf application and any other listening devices
            if(String.IsNullOrEmpty(txtOrder.Text))
            {
                DiagnosticsHelper.SafeShow("Please enter the order.","Take My Order",MessageBoxButton.OK);
                return;
            }
            App.Order.SendOrder(txtOrder.Text, TableSlider.Value.ToString(), spiceSlider.Value.ToString());
            DiagnosticsHelper.SafeShow("Order Sent.", "Take My Order", MessageBoxButton.OK);
            //Reset values
            TableSlider.Value = 1;
            spiceSlider.Value = 1;
            txtOrder.Text="";
        }

      

      
    }
}