﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace PointOfSaleApp
{
    public partial class MainPage : UserControl
    {
        /// <summary>
        /// My Machine Name
        /// </summary>
        string POIName = "Host";
       
        public MainPage()
        {
            InitializeComponent();
            App.Order.Join(POIName);
            lblTitle.Content = lblTitle.Content + " :" + POIName;
            InitializeDataGrids();
            //Add a handler to handle incoming orders
            App.Order.DataReceivedFromDevice += new DataReceivedFromDeviceEventHandler(Order_DataReceivedFromDevice);
        }

        /// <summary>
        /// Handles incoming orders
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Order_DataReceivedFromDevice(object sender, OrderReceivedEventArgs e)
        {
            int OrderID = App.OrdersCollection.Count +1;
            Orders objOrders = new Orders(OrderID, e.tableNumber, e.spiceLevel, e.order);
            App.OrdersCollection.Add(objOrders);
        }


        private void InitializeDataGrids()
        {
            this.serversDataGrid.ItemsSource = App.Devices;
            this.incomingOrdersDataGrid.ItemsSource = App.OrdersCollection;
        }

        /// <summary>
        /// Clicked to send order status to connected devices
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOrderReady_Click(object sender, RoutedEventArgs e)
        {
            if ((from n in App.OrdersCollection where n.Status.ToLower() == Orders.OrderInProcessStatus.ToLower() && n.Chosen == true select n).Count() > 0
                &&
                (from n in App.OrdersCollection where n.Status.ToLower() == Orders.OrderCompleteStatus.ToLower() && n.Chosen == true select n).Count() == 0
                )
            {
                //Send order
                foreach (Orders s in App.OrdersCollection)
                {
                    if (s.Status == Orders.OrderInProcessStatus && s.Chosen)
                    {
                        s.Chosen = false;
                        s.Status = Orders.OrderCompleteStatus;
                        // Sending via socket
                        App.Order.SendOrderStatus(s.OrderID, s.Status);
                    }
                }
            }
            else
            {
                DiagnosticsHelper.SafeShow("Please select orders that are '" + Orders.OrderInProcessStatus + "'", "Point of Sale", MessageBoxButton.OK);
            }

            
        }
        
        /// <summary>
        /// Exits the application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.MainWindow.Close();
        }
        

       
    }
}
