﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace PointOfSaleApp
{
     /// <summary>
     /// Orders class. The Point Of Sale APP uses this object to track the orders through to Complete Status.
     /// This class must implement INotifyPropertyChanged as it is 
     /// bound to a datagrid using an observable collection.
     /// </summary>
    public class Orders: INotifyPropertyChanged
    {

        public   const string OrderCompleteStatus = "Complete";
        public  const string OrderInProcessStatus = "In Process";
        int _orderID;
        int _tableNumber;
        int _spiceLevel;
        string _order;
        bool _chosen;
        string _status;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="orderID"></param>
        /// <param name="tableNumber"></param>
        /// <param name="spiceLevel"></param>
        /// <param name="order"></param>
        public Orders(int orderID,int tableNumber, int spiceLevel,string order)
        {
            _orderID = orderID;
            _tableNumber = tableNumber;
            _spiceLevel = spiceLevel;
            _order = order;
            _chosen = false;
            _status = OrderInProcessStatus;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }

        /// <summary>
        /// Unique Order ID
        /// </summary>
        public int OrderID { 
            get
            {
                return _orderID;
            }
            set
            {
                _orderID = value;
                NotifyPropertyChanged("OrderID");
            }
        }

        /// <summary>
        /// Table
        /// </summary>
        public int TableNumber{
            get
            {
                return _tableNumber;
            }
            set
            {
                _tableNumber = value;
                NotifyPropertyChanged("TableNumber");
            }
        }

        /// <summary>
        /// Spice level
        /// </summary>
        public int SpiceLevel {
            get
            {
                return _spiceLevel;
            }
            set
            {
                _spiceLevel = value;
                NotifyPropertyChanged("SpiceLevel");
            } 
        }

        /// <summary>
        /// The order text itself
        /// </summary>
        public string Order {
            get
            {
                return _order;
            }
            set
            {
                _order = value;
                NotifyPropertyChanged("Order");
            }
        }

        /// <summary>
        /// Bound to the checkbox on the datagrid
        /// </summary>
        public bool Chosen {
            get
            {
                return _chosen;
            }
            set
            {
                _chosen = value;
                NotifyPropertyChanged("Chosen");
            } 
        }

        /// <summary>
        /// Status of the order
        /// </summary>
        public string Status
        {
            get
            {
                return _status;
            }
            set
            {
                _status = value;
                NotifyPropertyChanged("Status");
            }
        }
    }
}
