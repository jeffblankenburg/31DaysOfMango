/* 
    Copyright (c) 2011 Microsoft Corporation.  All rights reserved.
    Use of this sample source code is subject to the terms of the Microsoft license 
    agreement under which you licensed this sample source code and is provided AS-IS.
    If you did not accept the terms of the license agreement, you are not authorized 
    to use this sample source code.  For the terms of the license, please see the 
    license agreement between you and Microsoft.
  
    To see all Code Samples for Windows Phone, visit http://go.microsoft.com/fwlink/?LinkID=219604 
  
*/
using System;
using System.Net;
using System.Windows;
using System.ComponentModel;

namespace PointOfSaleApp
{
    /// <summary>
    /// The information about each device. This class must implement INotifyPropertyChanged as it is
    /// bound to a datagrid using an observable collection.
    /// </summary>
    public class DeviceInfo:INotifyPropertyChanged
    {
        private IPEndPoint _DeviceEndPoint;
        private string _DeviceOrServerName;
        
        public DeviceInfo(string deviceOrServerName, IPEndPoint endPoint)
        {
            _DeviceEndPoint = endPoint;
            _DeviceOrServerName = deviceOrServerName;
        }

        public DeviceInfo(string deviceOrServerName)
        {
            _DeviceEndPoint = null;
            _DeviceOrServerName = deviceOrServerName;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }

        /// <summary>
        /// Device End Point
        /// </summary>
        public IPEndPoint DeviceEndPoint { 
            get
            {
                return _DeviceEndPoint;
            }
            set
            {
                _DeviceEndPoint = value;
                NotifyPropertyChanged("DeviceEndPoint");
            }
        }
        
        /// <summary>
        /// Name of the Device(for the host) or the name of the server
        /// </summary>
        public string DeviceOrServerName { 
            get
            {
                return _DeviceOrServerName;
            } 
            set
            {
                _DeviceOrServerName = value;
                NotifyPropertyChanged("DeviceOrServerName");
            } 
        }
    }
}
