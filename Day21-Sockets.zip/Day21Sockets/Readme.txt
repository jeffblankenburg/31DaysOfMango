NOTE: 
This socket application is based on the Multicast socket application available for download from 
http://msdn.microsoft.com/en-us/library/ff431744(v=vs.92).aspx

The sample name is Multicast Sockets Sample 

This socket application uses UDP to trasmit the information. 
Both the host (Point of Sale Silverlight Application) and the Windows Phone 7 application cannot communicate on the same host.

If you have a windows phone, set the windows phone application to launch in the device and then run the solution. 
Otherwise,deploy the silverlight application in a virtual machine and run the windows phone 7 application on the host.