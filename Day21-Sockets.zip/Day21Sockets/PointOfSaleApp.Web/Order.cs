/* 
    Copyright (c) 2011 Microsoft Corporation.  All rights reserved.
    Use of this sample source code is subject to the terms of the Microsoft license 
    agreement under which you licensed this sample source code and is provided AS-IS.
    If you did not accept the terms of the license agreement, you are not authorized 
    to use this sample source code.  For the terms of the license, please see the 
    license agreement between you and Microsoft.
  
    To see all Code Samples for Windows Phone, visit http://go.microsoft.com/fwlink/?LinkID=219604 
  
*/
using System;
using System.Linq;
using System.Diagnostics;
using System.Windows;
using System.Windows.Threading;

namespace TakeMyOrder
{
    /// <summary>
    /// This class handles all application communication. Communication for the application is made up of
    /// a number of commands that we have defined in the RestaurantCommand.cs class. These commands 
    /// are the grammar, or set of actions, that we can transmit and receive and interpret.
    /// </summary>
    public class Order : IDisposable
    {
        /// <summary>
        /// All communication takes place using a UdpAnySourceMulticastChannel. 
        /// A UdpAnySourceMulticastChannel is a wrapper we create around the UdpAnySourceMulticastClient.
        /// </summary>
        /// <value>The channel.</value>
        private UdpAnySourceMulticastChannel Channel { get; set; }

        /// <summary>
        /// The IP address of the multicast group. 
        /// </summary>
        /// <remarks>
        /// A multicast group is defined by a multicast group address, which is an IP address 
        /// that must be in the range from 224.0.0.0 to 239.255.255.255. Multicast addresses in 
        /// the range from 224.0.0.0 to 224.0.0.255 inclusive are “well-known” reserved multicast 
        /// addresses. For example, 224.0.0.0 is the Base address, 224.0.0.1 is the multicast group 
        /// address that represents all systems on the same physical network, and 224.0.0.2 represents 
        /// all routers on the same physical network.The Internet Assigned Numbers Authority (IANA) is 
        /// responsible for this list of reserved addresses. For more information on the reserved 
        /// address assignments, please see the IANA website.
        /// http://go.microsoft.com/fwlink/?LinkId=221630
        /// </remarks>
        private const string GROUP_ADDRESS = "224.0.1.11";

        /// <summary>
        /// This defines the port number through which all communication with the multicast group will take place. 
        /// </summary>
        /// <remarks>
        /// The value in this example is arbitrary and you are free to choose your own.
        /// </remarks>
        private const int GROUP_PORT = 54329;
        
        /// <summary>
        /// The name of this player.
        /// </summary>
        private string _serverName;

        public Order()
        {
            this.Channel = new UdpAnySourceMulticastChannel(GROUP_ADDRESS, GROUP_PORT);

            // Register for events on the multicast channel.
            RegisterEvents();

            // Send a message to the multicast group regularly. This is done because
            // we use UDP unicast messages during the application, sending messages directly to 
            // our opponent. This uses the BeginSendTo method on UpdAnySourceMulticastClient
            // and according to the documentation:
            // "The transmission is only allowed if the address specified in the remoteEndPoint
            // parameter has already sent a multicast packet to this receiver"
            // So, if everyone sends a message to the multicast group, we are guaranteed that this 
            // player (receiver) has been sent a multicast packet by the opponent. 
            StartKeepAlive();
        }

        #region Properties
        ///// <summary>
        ///// The player, against whom, I am currently playing.
        ///// </summary>
        //private DeviceInfo _currentDevice;
        //public DeviceInfo CurrentDevice
        //{
        //    get
        //    {
        //        return _currentDevice;
        //    }
        //}

        /// <summary>
        /// Whether we are joined to the multicast group
        /// </summary>
        public bool IsJoined { get; private set; }
        #endregion

        #region application Actions
        /// <summary>
        /// Join the multicast group.
        /// </summary>
        /// <param name="serverName">The server name I want to join as.</param>
        /// <remarks>The server name is not needed for multicast communication. it is 
        /// used in this example to identify each member of the multicast group with 
        /// a friendly name. </remarks>
        public void Join(string serverName)
        {
            if (IsJoined)
            {
                return;
            }

            // Store my player name
            _serverName = serverName;

            //Open the connection
            this.Channel.Open();
        }

        /// <summary>
        /// Send a message to the given opponent to challenge him to a application.
        /// </summary>
        /// <param name="opponentName">The identifier for the opponent to challenge.</param>
        public void Challenge(string opponentName)
        {
            // Look for this opponent in the list of oppoennts in the group
            //PlayerInfo opponent = App.Players.Where(player => player.PlayerName == opponentName).SingleOrDefault();
            //if (opponent != null)
            //{
            //    this.Channel.SendTo(opponent.PlayerEndPoint, RestaurantCommands.ChallengeFormat, _playerName);
            //}
            //else
            //{
            //    DiagnosticsHelper.SafeShow("Opponent is null!");
            //}
        }

       
        public void SendOrder(string Order,string tableNumber, string spiceLevel)
        {
            foreach (DeviceInfo di in App.Devices)
            {
                //Send order to all devices. Only the server will process the send order command. Others will simply ignore it.
                this.Channel.SendTo(di.DeviceEndPoint, RestaurantCommands.SendOrderFormatFormat, _serverName, Order, tableNumber, spiceLevel);
            }
        }

        #endregion

        #region Multicast Communication
        /// <summary>
        /// Register for events on the multicast channel.
        /// </summary>
        private void RegisterEvents()
        {
            // Register for events from the multicast channel
            this.Channel.Joined += new EventHandler(Channel_Joined);
            this.Channel.BeforeClose += new EventHandler(Channel_BeforeClose);
            this.Channel.PacketReceived += new EventHandler<UdpPacketReceivedEventArgs>(Channel_PacketReceived);
        }

        /// <summary>
        /// Unregister for events on the multicast channel
        /// </summary>
        private void UnregisterEvents()
        {
            if (this.Channel != null)
            {
                // Register for events from the multicast channel
                this.Channel.Joined -= new EventHandler(Channel_Joined);
                this.Channel.BeforeClose -= new EventHandler(Channel_BeforeClose);
                this.Channel.PacketReceived -= new EventHandler<UdpPacketReceivedEventArgs>(Channel_PacketReceived);
            }
        }
        /// <summary>
        /// Handles the BeforeClose event of the Channel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        void Channel_BeforeClose(object sender, EventArgs e)
        {
            this.Channel.Send(String.Format(RestaurantCommands.Leave, _serverName));
        }

        /// <summary>
        /// Handles the Joined event of the Channel.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        void Channel_Joined(object sender, EventArgs e)
        {
            this.IsJoined = true;
            this.Channel.Send(RestaurantCommands.JoinFormat, _serverName);
        }

        /// <summary>
        /// Handles the PacketReceived event of the Channel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="SilverlightPlayground.UDPMulticast.UdpPacketReceivedEventArgs"/> instance containing the event data.</param>
        void Channel_PacketReceived(object sender, UdpPacketReceivedEventArgs e)
        {
            string message = e.Message.Trim('\0');
            string[] messageParts = message.Split(RestaurantCommands.CommandDelimeter.ToCharArray());

            if (messageParts.Length == 2)
            {
                switch (messageParts[0])
                {
                    case RestaurantCommands.Join:
                        OnDeviceJoined(new DeviceInfo(messageParts[1], e.Source));
                        break;
                    case RestaurantCommands.Leave:
                        OnDeviceLeft(new DeviceInfo(messageParts[1], e.Source));
                        break;
                    case RestaurantCommands.Ready:
                        Debug.WriteLine("Ready received");
                        break;
                    default:
                        break;
                }
                

            }
            else if (messageParts.Length == 3 && messageParts[0] == RestaurantCommands.ReceiveOrder)
            {
                //Status of order received
                OrderStatusReceivedEventArgs args = new OrderStatusReceivedEventArgs();
                args.orderId = Convert.ToInt32(messageParts[1]);
                args.orderStatus = messageParts[2];
                if (DataReceivedFromDevice != null)
                {
                    DataReceivedFromDevice(this, args);
                }
            }
            else
            {
                // Ignore messages that don't have the expected number of parts.
            }
        }

        /// <summary>
        /// Leave the multicast group. We will not show up in the list of opponents on any
        /// other client devices.
        /// </summary>
        public void Leave(bool disconnect)
        {
            if (this.Channel != null)
            {
                // Tell everyone we have left
                this.Channel.Send(RestaurantCommands.LeaveFormat, _serverName);

                // Only close the underlying communications channel to the multicast group
                // if disconnect == true.
                if (disconnect)
                {
                    this.Channel.Close();
                }

            }

            //// Clear the opponent
            //_currentDevice = null;
            this.IsJoined = false;
        }
        #endregion

        #region Command Handlers - methods to handle each command that we receive
        /// <summary>
        /// Handle a device joining the multicast group.
        /// </summary>
        /// <param name="deviceInfo">The player.</param>
        private void OnDeviceJoined(DeviceInfo deviceInfo)
        {
            bool add = true;
            int numberAdded = 0;

            foreach (DeviceInfo di in App.Devices)
            {
                if (di.DeviceOrServerName == deviceInfo.DeviceOrServerName)
                {

                    di.DeviceEndPoint = deviceInfo.DeviceEndPoint;

                    add = false;
                    break;
                }
            }

            if (add)
            {
                numberAdded++;
                App.Devices.Add(deviceInfo);
            }

            // If any new players have been added, send out our join message again
            // to make sure we are added to their player list.
            if (numberAdded > 0)
            {
                this.Channel.Send(RestaurantCommands.JoinFormat, _serverName);
            }

#if DEBUG
            Debug.WriteLine(" =========   DEVICES =============");
            foreach (DeviceInfo di in App.Devices)
            {
                Debug.WriteLine(string.Format("{1} [{0}]", di.DeviceOrServerName, di.DeviceEndPoint));
            }
#endif
        }

       


        /// <summary>
        /// Handle a device leaving the multicast group.
        /// </summary>
        /// <param name="deviceInfo">The player.</param>
        private void OnDeviceLeft(DeviceInfo deviceInfo)
        {
            if(deviceInfo.DeviceOrServerName != _serverName)
            {
                foreach (DeviceInfo di in App.Devices)
                {
                    if (di.DeviceOrServerName == deviceInfo.DeviceOrServerName)
                    {
                        App.Devices.Remove(di);
                        break;
                    }
                }
            }

            OnLeave(deviceInfo);
        }

        /// <summary>
        /// Handle a Device leaving.
        /// </summary>
        /// <param name="deviceInfo">The Device.</param>
        private void OnLeave(DeviceInfo deviceInfo)
        {
            //No Current processing needed
        }

        public event DataReceivedFromDeviceEventHandler DataReceivedFromDevice;
       
        #endregion

        #region Keep-Alive
        DispatcherTimer _dt;
        private void StartKeepAlive()
        {
            if (_dt == null)
            {
                _dt = new DispatcherTimer();
                _dt.Interval = new TimeSpan(0, 0, 1);
                _dt.Tick +=
                            delegate(object s, EventArgs args)
                            {
                                if (this.Channel != null && IsJoined)
                                {
                                    this.Channel.Send(RestaurantCommands.ReadyFormat, _serverName);
                                }
                            };
            }
            _dt.Start();

        }


        private void StopkeepAlive()
        {
            if (_dt != null)
                _dt.Stop();
        }
        #endregion

        #region IDisposable Implementation
        public void Dispose()
        {
            UnregisterEvents();
            StopkeepAlive();
        }
        #endregion

    }

    // A delegate type for hooking up change notifications.
    public delegate void DataReceivedFromDeviceEventHandler(object sender, OrderStatusReceivedEventArgs e);
    //public delegate void NewGameRequestedHandler(object sender, PlayerEventArgs e);
    //public delegate void LeftGameHandler(object sender, PlayerEventArgs e);

    //public class PlayerEventArgs : EventArgs
    //{
    //    public DeviceInfo playerInfo { get; set; }
    //}

    /// <summary>
    /// When we receive a message that the opponent has played, we pass
    /// on the playerInfo and the gamepiece they played.
    /// </summary>
    public class OrderStatusReceivedEventArgs : EventArgs
    {
        public int orderId { get; set; }
        public string orderStatus { get; set; }
    }
}
