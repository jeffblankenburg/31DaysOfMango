﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Scheduler;

namespace MyAgentApp
{
    public partial class MainPage : PhoneApplicationPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private const string TASK_NAME = "MyAgent";

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            StartAgent();
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            StopAgentIfStarted();
        }

        private void StartAgent()
        {
            StopAgentIfStarted();

            PeriodicTask task = new PeriodicTask(TASK_NAME);
            task.Description = "This is our custom agent for Day 25 - Background Agents";
            ScheduledActionService.Add(task);
#if DEBUG
            // If we're debugging, attempt to start the task immediately
            ScheduledActionService.LaunchForTest(TASK_NAME, new TimeSpan(0, 0, 1));
#endif
        }

        private void StopAgentIfStarted()
        {
            if (ScheduledActionService.Find(TASK_NAME) != null)
            {
                ScheduledActionService.Remove(TASK_NAME);
            }
        }
    }
}