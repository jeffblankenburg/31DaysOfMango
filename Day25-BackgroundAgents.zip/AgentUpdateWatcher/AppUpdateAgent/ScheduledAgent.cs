﻿using System.Windows;
using Microsoft.Phone.Scheduler;
using System;
using System.Linq;
using Microsoft.Phone.Shell;

namespace MyAgent
{
    public class ScheduledAgent : ScheduledTaskAgent
    {
        private static volatile bool _classInitialized;

        public ScheduledAgent()
        {
            if (!_classInitialized)
            {
                _classInitialized = true;
                Deployment.Current.Dispatcher.BeginInvoke(delegate
                {
                    Application.Current.UnhandledException += ScheduledAgent_UnhandledException;
                });
            }
        }

        protected override void OnInvoke(ScheduledTask task)
        {
            UpdateAppTile(GetLastUpdatedTimeMessage());
        }

        private string GetLastUpdatedTimeMessage()
        {
            return string.Format("Last Updated: {0}", DateTime.Now);
        }

        private void UpdateAppTile(string message)
        {
            ShellTile appTile = ShellTile.ActiveTiles.First();
            if (appTile != null)
            {
                StandardTileData tileData = new StandardTileData
                {
                    BackContent = message
                };

                appTile.Update(tileData);
            }
        }

        private void ScheduledAgent_UnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e)
        {
            if (System.Diagnostics.Debugger.IsAttached)
            {
                System.Diagnostics.Debugger.Break();
            }
        }
    }
}