﻿using System;
using System.Text;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Net.NetworkInformation;

namespace Day10_NetworkInformation
{
	public partial class MainPage : PhoneApplicationPage
	{

		public MainPage()
		{
			InitializeComponent();
			DeviceNetworkInformation.NetworkAvailabilityChanged += new EventHandler<NetworkNotificationEventArgs>(DeviceNetworkInformation_NetworkAvailabilityChanged);
			GetData();
		}

		private void GetData()
		{
			StringBuilder info = new StringBuilder();

			if (DeviceNetworkInformation.CellularMobileOperator != null)
				info.AppendLine("carrier: " + DeviceNetworkInformation.CellularMobileOperator.ToLower());

			info.AppendLine("network: " + DeviceNetworkInformation.IsNetworkAvailable.ToString());
			info.AppendLine("roaming: " + DeviceNetworkInformation.IsCellularDataRoamingEnabled.ToString());
			info.AppendLine("cellular: " + DeviceNetworkInformation.IsCellularDataEnabled.ToString());
			info.AppendLine("wifi: " + DeviceNetworkInformation.IsWiFiEnabled.ToString());

			info.AppendLine();

			foreach (var n in new NetworkInterfaceList())
			{
				info.AppendLine(n.InterfaceName.ToLower());
				info.AppendLine(n.InterfaceType.ToString());
				info.AppendLine(n.InterfaceState.ToString());
				info.AppendLine();
			}

			ContentBox.Text = info.ToString();
		}

		void DeviceNetworkInformation_NetworkAvailabilityChanged(object sender, NetworkNotificationEventArgs e)
		{
			GetData();
		}
	}
}