﻿using System;
using System.Windows.Media;
using Microsoft.Phone.Controls;
using Microsoft.Devices.Sensors;
using Microsoft.Xna.Framework;

namespace Day6_Motion
{
	public partial class MainPage : PhoneApplicationPage
	{
		Motion motion;
		
		public MainPage()
		{
			InitializeComponent();

			if (Motion.IsSupported)
			{
				motion = new Motion();
				motion.TimeBetweenUpdates = TimeSpan.FromMilliseconds(20);
				motion.CurrentValueChanged += new EventHandler<SensorReadingEventArgs<MotionReading>>(motion_CurrentValueChanged);
				motion.Start();
			}
		}

		void motion_CurrentValueChanged(object sender, SensorReadingEventArgs<MotionReading> e)
        {
            Dispatcher.BeginInvoke(() => UpdateUI(e.SensorReading));
        }

        private void UpdateUI(MotionReading e)
        {
            ((RotateTransform)Star.RenderTransform).Angle = MathHelper.ToDegrees(e.Attitude.Yaw);
            yawValue.Text = "YAW = " + e.Attitude.Yaw.ToString();

			float pitch = e.Attitude.Pitch;
			float yaw = e.Attitude.Yaw;
			float roll = e.Attitude.Roll;

			float accelerometerX = e.DeviceAcceleration.X;
			float accelerometerY = e.DeviceAcceleration.Y;
			float accelerometerZ = e.DeviceAcceleration.Z;

			float gyroscopeX = e.DeviceRotationRate.X;
			float gyroscopeY = e.DeviceRotationRate.Y;
			float gyroscopeZ = e.DeviceRotationRate.Z;

			float gravityX = e.Gravity.X;
			float gravityY = e.Gravity.Y;
			float gravityZ = e.Gravity.Z;

			DateTimeOffset timestamp = e.Timestamp;
        }
	}
}