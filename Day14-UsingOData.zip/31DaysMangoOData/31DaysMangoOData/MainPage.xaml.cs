﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Data.Services.Client;
using _31DaysMangoOData.ServiceReference1;

namespace _31DaysMangoOData
{
    public partial class MainPage : PhoneApplicationPage
    {
        private TeamFranchise _selectedTeam;
        private BaseballStatsEntities _context;

        // Constructor
        public MainPage()
        {
            InitializeComponent();

            DataContext = App.ViewModel;
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            _context = new BaseballStatsEntities(new Uri("http://www.baseball-stats.info/OData/baseballstats.svc/"));

            App.ViewModel.Teams.LoadCompleted += Teams_Loaded;

            var query = from t in _context.TeamFranchise
                        orderby
                            t.franchName
                        where t.active == "Y"
                        select t;
            App.ViewModel.Teams.LoadAsync(query);
        }

        private void Teams_Loaded(object sender, LoadCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                if (App.ViewModel.Teams.Continuation != null)
                {
                    App.ViewModel.Teams.LoadNextPartialSetAsync();
                }
                else
                {
                    // Set the data context of the list box control to the team data.
                    this.LayoutRoot.DataContext = App.ViewModel.Teams;
                }
            }
            else
            {
                MessageBox.Show(string.Format("We have an error: {0}", e.Error.Message));
            }
        }

        private void MainListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selectedTeam = MainListBox.SelectedItem as TeamFranchise;
            if (_selectedTeam != null)
            {
                NavigationService.Navigate(new Uri("/DetailsPage.xaml?selectedItem=" + MainListBox.SelectedIndex, UriKind.Relative));
            }

        }
    }
}