﻿using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Day16_IsolatedStorageExplorer
{
    public partial class FileContent : PhoneApplicationPage
    {
        #region "Members"

        string currentFileName;

        #endregion

        #region "Constructor"

        public FileContent()
        {
            InitializeComponent();
        }

        #endregion        

        #region "Event Handlers"

        private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
        {
            if (this.NavigationContext.QueryString.ContainsKey("FileName"))
            {
                currentFileName = this.NavigationContext.QueryString["FileName"];
                this.actualFileName.Text = currentFileName;

                this.ReadFileData(currentFileName);
            }
        }        

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.EditFileData(currentFileName);
        }

        #endregion

        #region "Methods"

        private void ReadFileData(string filePath)
        {
            using (IsolatedStorageFile appIsolatedStorage = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (appIsolatedStorage.FileExists(filePath))
                {
                    using (IsolatedStorageFileStream fileStream = appIsolatedStorage.OpenFile(filePath, FileMode.Open, FileAccess.Read))
                    {
                        using (StreamReader reader = new StreamReader(fileStream))
                        {
                            this.fileContent.Text = reader.ReadLine();
                        }
                    }
                }                
            }
        }

        private void EditFileData(string filePath)
        {
            using (IsolatedStorageFile appIsolatedStorage = IsolatedStorageFile.GetUserStoreForApplication())
            {                
                if (appIsolatedStorage.FileExists(filePath))
                {
                    using (IsolatedStorageFileStream fileStream = appIsolatedStorage.OpenFile(filePath, FileMode.Open, FileAccess.Write))
                    {
                        using (StreamWriter writer = new StreamWriter(fileStream))
                        {
                            string editedText = this.fileContent.Text.Trim();
                            writer.Write(editedText);
                            writer.Close();
                        }
                    }
                }
            }

            this.NavigationService.Navigate(new Uri("/DirectoryListings.xaml", UriKind.Relative));
        }

        #endregion
    }
}