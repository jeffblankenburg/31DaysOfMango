﻿using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Day16_IsolatedStorageExplorer
{
    public partial class MainPage : PhoneApplicationPage
    {
        #region "Members"

        IsolatedStorageFile fileStorage;
        string[] rootFiles;
        string[] directories;
        string[] directoryFiles;

        List<DirectorySystem> listDirectorySystem = new List<DirectorySystem>();

        #endregion

        #region "Constructor"

        public MainPage()
        {
            InitializeComponent();

            // Create a reference to the App's Isolated Storage
            fileStorage = IsolatedStorageFile.GetUserStoreForApplication();

            // Create initial sample Files & Directories, for fresh App Launch only.
            if ((App.Current as Day16_IsolatedStorageExplorer.App).FirstLaunch)
                this.CreateInitialFilesAndDirectories();

            // Reset the flag.
            (App.Current as Day16_IsolatedStorageExplorer.App).FirstLaunch = false;

            // Read root files.
            rootFiles = fileStorage.GetFileNames();
            this.RootListBox.ItemsSource = rootFiles;

            // Read Directories & build File system.
            directories = fileStorage.GetDirectoryNames();

            foreach (string dir in directories)
            {                
                directoryFiles = fileStorage.GetFileNames(dir + "\\*");

                DirectorySystem newDir = new DirectorySystem();
                newDir.DirectoryName = dir;
                newDir.DirectoryFiles = directoryFiles;

                listDirectorySystem.Add(newDir);
            }

            // Bind to UI.
            this.DirectorySystemListBox.ItemsSource = listDirectorySystem;
        }

        #endregion

        #region "Private Methods"

        private void CreateInitialFilesAndDirectories()
        {
            // Create a new StreamWriter, to write files to the root directory.
            StreamWriter fileWriter = new StreamWriter(new IsolatedStorageFileStream("RootFile1.txt", FileMode.OpenOrCreate, fileStorage));

            // Write sample data.
            fileWriter.WriteLine("This is test data.");

            // Close the StreamWriter.
            fileWriter.Close();

            // Repeat.
            fileWriter = new StreamWriter(new IsolatedStorageFileStream("RootFile2.txt", FileMode.OpenOrCreate, fileStorage));
            fileWriter.WriteLine("This is test data.");
            fileWriter.Close();

            // Create 2 new SubDirectories.
            fileStorage.CreateDirectory("SubDirectory1");
            fileStorage.CreateDirectory("SubDirectory2");

            // Put sample files in them.
            fileWriter = new StreamWriter(new IsolatedStorageFileStream("SubDirectory1\\SubDir1File1.txt", FileMode.OpenOrCreate, fileStorage));            
            fileWriter.WriteLine("This is test data.");            
            fileWriter.Close();
            fileWriter = new StreamWriter(new IsolatedStorageFileStream("SubDirectory1\\SubDir1File2.txt", FileMode.OpenOrCreate, fileStorage));
            fileWriter.WriteLine("This is test data.");
            fileWriter.Close();
            fileWriter = new StreamWriter(new IsolatedStorageFileStream("SubDirectory2\\SubDir2File2.txt", FileMode.OpenOrCreate, fileStorage));
            fileWriter.WriteLine("This is test data.");
            fileWriter.Close();            
        }

        #endregion        

        #region "Event Handlers

        private void RootListBox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (this.RootListBox.SelectedItem != null)
            {
                string selectedFileName = this.RootListBox.SelectedItem.ToString();
                this.NavigationService.Navigate(new Uri("/FileContent.xaml?FileName=" + selectedFileName, UriKind.Relative));

                this.RootListBox.SelectedItem = null;
            }
        }

        #endregion
    }

    public class DirectorySystem
    {
        public string DirectoryName { get; set; }
        public string[] DirectoryFiles { get; set; }
    }
}