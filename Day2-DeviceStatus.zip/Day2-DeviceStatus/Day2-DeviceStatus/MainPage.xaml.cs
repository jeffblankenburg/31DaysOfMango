﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Info;

namespace Day2_DeviceStatus
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();
			DeviceManufacturer.Text = DeviceStatus.DeviceManufacturer;
			DeviceName.Text = DeviceStatus.DeviceName;
			FirmwareVersion.Text = DeviceStatus.DeviceFirmwareVersion;
			HardwareVersion.Text = DeviceStatus.DeviceHardwareVersion;
			DeviceTotalMemory.Text = DeviceStatus.DeviceTotalMemory.ToString();
			ApplicationCurrentMemoryUsage.Text = DeviceStatus.ApplicationCurrentMemoryUsage.ToString();
			ApplicationMemoryUsageLimit.Text = DeviceStatus.ApplicationMemoryUsageLimit.ToString();
			ApplicationPeakMemoryUsage.Text = DeviceStatus.ApplicationPeakMemoryUsage.ToString();
			IsKeyboardPresent.Text = DeviceStatus.IsKeyboardPresent.ToString();
			IsKeyboardDeployed.Text = DeviceStatus.IsKeyboardDeployed.ToString();
			PowerSource.Text = DeviceStatus.PowerSource.ToString();
			DeviceStatus.PowerSourceChanged += new EventHandler(DeviceStatus_PowerSourceChanged);
			DeviceStatus.KeyboardDeployedChanged += new EventHandler(DeviceStatus_KeyboardDeployedChanged);
		}

		void DeviceStatus_KeyboardDeployedChanged(object sender, EventArgs e)
		{
			Dispatcher.BeginInvoke(() => IsKeyboardDeployed.Text = DeviceStatus.IsKeyboardDeployed.ToString());
		}

		void DeviceStatus_PowerSourceChanged(object sender, EventArgs e)
		{
			Dispatcher.BeginInvoke(() => PowerSource.Text = DeviceStatus.PowerSource.ToString());
		}
	}
}