﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.BackgroundTransfer;
using Microsoft.Phone.Tasks;
using System.IO.IsolatedStorage;

namespace MyFileTransferApp
{
    public partial class MainPage : PhoneApplicationPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private const String SAVE_LOCATION = "shared/transfers/MyDownloadedVideo.mp4";
        private Uri videoDownloadUri = new Uri("http://video.ch9.ms/ch9/02df/0a2774a9-a010-4b9b-b654-9f88014102df/xboxCompanion_med_ch9.mp4");
        private Uri saveLocationUri = new Uri(SAVE_LOCATION, UriKind.RelativeOrAbsolute);
        private BackgroundTransferRequest _currentRequest = null;

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            foreach (BackgroundTransferRequest request in BackgroundTransferService.Requests)
            {
                _currentRequest = request;
                break;
            }

            InitializeCurrentTransferRequest();
            InitializeTransferRequestEventHandlers();
            RefreshTransferUI();
        }

        private void InitializeCurrentTransferRequest()
        {
            foreach (BackgroundTransferRequest request in BackgroundTransferService.Requests)
            {
                _currentRequest = request;
                break;
            }
        }

        private void InitializeTransferRequestEventHandlers()
        {
            if (_currentRequest != null)
            {
                _currentRequest.TransferProgressChanged += new EventHandler<BackgroundTransferEventArgs>(_currentRequest_TransferProgressChanged);
                _currentRequest.TransferStatusChanged += new EventHandler<BackgroundTransferEventArgs>(_currentRequest_TransferStatusChanged);
            }
        }

        private void RefreshTransferUI()
        {
            RefreshTransferProgressUI();
            RefreshTransferStatusUI();
        }

        private void RefreshTransferStatusUI()
        {
            String statusMessage = "";
            if (_currentRequest != null)
            {
                playVideoButton.IsEnabled = (_currentRequest.TransferStatus == TransferStatus.Completed);

                if (_currentRequest.TransferStatus == TransferStatus.Completed &&
                   _currentRequest.TransferError!= null)
                {
                    statusMessage = String.Format("Status: {0}", _currentRequest.TransferError.Message);
                }
                else
                {
                    statusMessage = String.Format("Status: {0}", _currentRequest.TransferStatus);
                }
            }
            statusText.Text = statusMessage;

        }

        private void RefreshTransferProgressUI()
        {
            String progressMessage = "";
            if (_currentRequest != null)
            {
                progressMessage = String.Format("Progress: {0} bytes / {1} bytes", 
                    _currentRequest.BytesReceived, _currentRequest.TotalBytesToReceive);
            }

            progressText.Text = progressMessage;
        }

        private void _currentRequest_TransferStatusChanged(object sender, BackgroundTransferEventArgs e)
        {
            RefreshTransferStatusUI();
        }

        private void _currentRequest_TransferProgressChanged(object sender, BackgroundTransferEventArgs e)
        {
            RefreshTransferProgressUI();
        }

        private void downloadButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentRequest != null)
            {
                BackgroundTransferService.Remove(_currentRequest);
            }

            DeleteVideoIfExists();
            AddTransferRequest();
            InitializeTransferRequestEventHandlers();
            RefreshTransferUI();
        }

        private void DeleteVideoIfExists()
        {
            using (IsolatedStorageFile userStore = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (userStore.FileExists(SAVE_LOCATION))
                {
                    userStore.DeleteFile(SAVE_LOCATION);
                }
            }
        }

        public void AddTransferRequest()
        {
            _currentRequest = new BackgroundTransferRequest(videoDownloadUri, saveLocationUri);
            _currentRequest.TransferPreferences = TransferPreferences.AllowCellularAndBattery;
            BackgroundTransferService.Add(_currentRequest);
        }

        private void playVideo_Click(object sender, RoutedEventArgs e)
        {
            MediaPlayerLauncher mediaPlayerLauncher = new MediaPlayerLauncher()
            {
                Media = saveLocationUri,
                Location = MediaLocationType.Data
            };

            mediaPlayerLauncher.Show();
        }
    }
}