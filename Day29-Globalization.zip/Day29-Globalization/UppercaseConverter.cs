using System;
using System.Globalization;
using System.Windows.Data;

namespace PhoneApp1
{
    public class UppercaseConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
            {
                return value;
            }

            var s = value.ToString();

            // Always use either the provided culture or CultureInfo.InvariantCulture
            return s.ToUpper(culture);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}