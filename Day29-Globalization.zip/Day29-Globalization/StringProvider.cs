namespace PhoneApp1
{
    public class StringProvider
    {
        private readonly Strings _resources = new Strings();

        public Strings Resources
        {
            get { return _resources; }
        }
    }
}