﻿using System;
using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Navigation;
using Microsoft.Devices;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.Phone.Tasks;

namespace PhoneApp1
{
    public partial class MainPage : PhoneApplicationPage
    {
        private EmailAddressChooserTask _chooser;

        public MainPage()
        {
            InitializeComponent();

            // Ensure that the app title uses all caps
            ApplicationTitle.Text = Strings.AppTitle.ToUpper(CultureInfo.CurrentCulture);

            // Specify the text explicitly on the app bar using our resource string.
            var button = (ApplicationBarIconButton)ApplicationBar.Buttons[0];
            button.Text = Strings.ButtonSend;

            // By default, we're going to be 15 minutes later than now
            timeArrival.Value = DateTime.Now.AddMinutes(15);
        }

        private void HandleChooseContactClick(object sender, RoutedEventArgs e)
        {
            // Lazilzy instantiate the chooser
            if (_chooser == null)
            {
                _chooser = new EmailAddressChooserTask();
                // When the chooser completes, store the result in the E-Mail To field
                _chooser.Completed += new EventHandler<EmailResult>(HandleChooserCompleted);
            }

            // Show the E-Mail chooser
            _chooser.Show();
        }

        private void HandleChooserCompleted(object sender, EmailResult e)
        {
            // Ensure that it completed successfully and that the user didn't cancel
            if (e.TaskResult == TaskResult.OK)
            {
                txtTo.Text = e.Email;
            }
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            // Remember our settings for app resume
            State["To"] = txtTo.Text;
            State["Subject"] = txtSubject.Text;
            State["Reason"] = txtReason.Text;
            State["Time"] = timeArrival.Value;
            State["IncludeETA"] = checkIncludeETA.IsChecked;
            State["IncludeReason"] = checkIncludeReason.IsChecked;
            State["IncludeDiagnostics"] = checkIncludeDiagnosticData.IsChecked;

            base.OnNavigatedFrom(e);
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            // Load our settings from last time, if present. Note that this doesn't affect new app starts.
            LoadTextFromState(txtTo, "To");
            LoadTextFromState(txtSubject, "Subject");
            LoadTextFromState(txtReason, "Reason");
            LoadDateTimeFromState(timeArrival, "Time");
            LoadIsCheckedFromState(checkIncludeETA, "IncludeETA");
            LoadIsCheckedFromState(checkIncludeReason, "IncludeReason");
            LoadIsCheckedFromState(checkIncludeDiagnosticData, "IncludeDiagnostics");

            base.OnNavigatedTo(e);
        }


        private void LoadDateTimeFromState(DateTimePickerBase timePicker, string key)
        {
            if (State.ContainsKey(key))
            {
                timePicker.Value = (DateTime?)State[key];
            }
        }

        private void LoadTextFromState(TextBox textBox, string key)
        {
            if (State.ContainsKey(key))
            {
                textBox.Text = (string)State[key];
            }
        }

        private void LoadIsCheckedFromState(ToggleButton checkBox, string key)
        {
            if (State.ContainsKey(key))
            {
                checkBox.IsChecked = (bool?)State[key];
            }
        }

        private void HandleSendClick(object sender, EventArgs e)
        {
            // Build the E-Mail body from the user's selections
            var body = new StringBuilder();
            body.AppendLine(Strings.EmailHeader);

            // Include reason if applicable
            var culture = CultureInfo.CurrentCulture;
            if (checkIncludeReason.IsChecked == true)
            {
                body.AppendLine();
                body.AppendLine(string.Format(culture, "{0}: {1}", Strings.EmailReason, txtReason.Text));
            }

            // Include eta if applicable
            if (checkIncludeETA.IsChecked == true)
            {
                body.AppendLine();
                // Since we've specified our ValueFormatString for the Time Picker, we can just rely on the ValueString here.
                body.AppendLine(string.Format(culture, "{0}: {1}", Strings.CheckShouldArriveBy, timeArrival.ValueString));
            }

            // Include extra globalization examples if applicable
            if (checkIncludeDiagnosticData.IsChecked == true)
            {
                body.AppendLine();
                // this is the standardized culture name such as en-US or zh-CH
                body.AppendLine(culture.Name); 
                body.AppendLine(string.Format(culture, "pi: {0}", Math.PI));
                body.AppendLine(string.Format(culture, "number: {0}", -1));
                body.AppendLine(string.Format(culture, "currency: {0:c}", 4200.00));
                body.AppendLine(string.Format(culture, "date: {0:D}", DateTime.Today));
                body.AppendLine(string.Format(culture, "time: {0:t}", DateTime.Now));
            }

            // Now that we have our message body, do something with it. What we do depends on what we're running on.
            if (Microsoft.Devices.Environment.DeviceType == DeviceType.Emulator)
            {
                // The emulator doesn't currently support sending E-Mails so we'll just output the text to a message box
                MessageBox.Show(body.ToString());
            }
            else
            {
                // Compose the E-Mail and show it to the user to preview before sending
                var task = new EmailComposeTask {Subject = txtSubject.Text, To = txtTo.Text, Body = body.ToString()};
                task.Show();
            }
        }
    }
}