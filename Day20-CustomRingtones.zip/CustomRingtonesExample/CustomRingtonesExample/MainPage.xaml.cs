﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;

namespace CustomRingtonesExample
{
    public partial class MainPage : PhoneApplicationPage
    {
        private readonly SaveRingtoneTask _customRingtone;
        
        public MainPage()
        {
            InitializeComponent();
            _customRingtone = new SaveRingtoneTask();
            _customRingtone.Completed += customRingtone_Completed;
        }

        private void customRingtone_Completed(object sender, TaskEventArgs e)
        {
            MessageBox.Show(@"You are back from the Ringtones application. Reference e.TaskResult, in your code, 
            if you want to see if the save was successful.");
        }

        private void SaveButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            _customRingtone.Source = new Uri("appdata:/Audio/ExampleRingtone.wma");
            _customRingtone.DisplayName = "Example Custom Ringtone";
            _customRingtone.Show();
        }
    }
}