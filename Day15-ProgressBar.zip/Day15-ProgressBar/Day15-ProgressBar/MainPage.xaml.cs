﻿using System;
using System.Windows;
using System.Windows.Threading;
using Microsoft.Phone.Shell;

namespace Day15_ProgressBar
{
    public partial class MainPage
    {
        // Constructor
        ProgressIndicator progressIndicator = new ProgressIndicator() { IsVisible = true, IsIndeterminate = false, Text = "Downloading file ..." };
        DispatcherTimer timer = new DispatcherTimer();
        public MainPage()
        {
            InitializeComponent();

            SystemTray.SetProgressIndicator(this, progressIndicator);

            timer = new DispatcherTimer {Interval = new TimeSpan(5000)};
            timer.Tick += timer_Tick;
            timer.Stop();
        }

        void timer_Tick(object sender, EventArgs e)
        {
            progressBar1.Value += progressBar1.SmallChange;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            progressBar1.Value = 0;
            timer.Start();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            progressBar1.Value = 0;
        }

        private void slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            progressIndicator.Value = e.NewValue;
        }
    }
}