﻿using System;
using System.Linq;
using System.Windows.Controls;
using Microsoft.Phone.Controls;
using Microsoft.Phone.UserData;
using System.Collections.Generic;

namespace Day8_ContactsAPI
{
	public partial class MainPage : PhoneApplicationPage
	{
		Contacts contacts = new Contacts();

		public MainPage()
		{
			InitializeComponent();
			contacts.SearchCompleted += new EventHandler<ContactsSearchEventArgs>(contacts_SearchCompleted);
			SearchContacts(String.Empty);
		}

		private void SearchTerm_TextChanged(object sender, TextChangedEventArgs e)
		{
			SearchContacts(SearchTerm.Text);
		}

		void contacts_SearchCompleted(object sender, ContactsSearchEventArgs e)
		{
			ContactList.ItemsSource = e.Results;
			
			//Grabbing the first record of our result.
			Contact patientZero = e.Results.FirstOrDefault();

			string firstname = patientZero.CompleteName.FirstName;
			string lastname = patientZero.CompleteName.LastName;

			string emailaddress = patientZero.EmailAddresses.FirstOrDefault().EmailAddress;
			string phonenumber = patientZero.PhoneNumbers.FirstOrDefault().PhoneNumber;

			bool isPinnedToStart = patientZero.IsPinnedToStart;
		}

		private void SearchContacts(string searchterm)
		{
			contacts.SearchAsync(searchterm, FilterKind.DisplayName, null);
		}
	}
}