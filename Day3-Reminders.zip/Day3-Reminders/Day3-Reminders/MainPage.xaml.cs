﻿using System;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Scheduler;

namespace Day3_Reminders
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();
		}

		private void AlarmButton_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			if (ScheduledActionService.Find("testalarm") != null)
				ScheduledActionService.Remove("testalarm");
			
			Alarm a = new Alarm("testalarm");
			a.Content = "Jeff Blankenburg's Alarm";
			a.Sound = new Uri("button-8.mp3", UriKind.Relative);
			a.BeginTime = DateTime.Now.AddSeconds(15);
			a.ExpirationTime = DateTime.Now.AddDays(7);
			a.RecurrenceType = RecurrenceInterval.Daily;

			ScheduledActionService.Add(a);
		}

		private void ReminderButton_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			if (ScheduledActionService.Find("testreminder") != null)
				ScheduledActionService.Remove("testreminder");

			Reminder r = new Reminder("testreminder");
			r.Title = "A Special Reminder";
			r.Content = "Jeff Blankenburg's Reminder";
			r.NavigationUri = new Uri("/ReminderPage.xaml", UriKind.Relative);
			r.BeginTime = DateTime.Now.AddSeconds(15);
			r.ExpirationTime = DateTime.Now.AddDays(7);
			r.RecurrenceType = RecurrenceInterval.Daily;

			ScheduledActionService.Add(r);
		}

		private void EditButton_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			if (ScheduledActionService.Find("testreminder") != null)
			{
				Reminder r = ScheduledActionService.Find("testreminder") as Reminder;
				r.Title = "This has been edited.";
				r.Content = "This is updated content.";
				r.BeginTime = DateTime.Now.AddSeconds(15);

				ScheduledActionService.Replace(r);
			}
		}
	}
}