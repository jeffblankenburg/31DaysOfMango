﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Devices;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using Microsoft.Xna.Framework.Media;

namespace Day7_RawCamera
{
	public partial class MainPage : PhoneApplicationPage
	{
		PhotoCamera camera;
		MediaLibrary library = new MediaLibrary();

		// Constructor
		public MainPage()
		{
			InitializeComponent();
		}

		protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
		{
			base.OnNavigatedTo(e);

			if (PhotoCamera.IsCameraTypeSupported(CameraType.FrontFacing))
				camera = new PhotoCamera(CameraType.FrontFacing);
			else
				camera = new PhotoCamera(CameraType.Primary);
			camera.CaptureImageAvailable += new System.EventHandler<ContentReadyEventArgs>(camera_CaptureImageAvailable);
			CameraSource.SetSource(camera);

			CameraButtons.ShutterKeyHalfPressed += new EventHandler(CameraButtons_ShutterKeyHalfPressed);
			CameraButtons.ShutterKeyPressed += new EventHandler(CameraButtons_ShutterKeyPressed);
			CameraButtons.ShutterKeyReleased += new EventHandler(CameraButtons_ShutterKeyReleased);
		}

		protected override void OnNavigatingFrom(System.Windows.Navigation.NavigatingCancelEventArgs e)
		{
			if (camera != null)
			{
				camera.Dispose();
				camera.CaptureImageAvailable -= camera_CaptureImageAvailable;
				CameraButtons.ShutterKeyHalfPressed -= CameraButtons_ShutterKeyHalfPressed;
				CameraButtons.ShutterKeyPressed -= CameraButtons_ShutterKeyPressed;
				CameraButtons.ShutterKeyReleased -= CameraButtons_ShutterKeyReleased;
			}
		}

		private void CaptureButton_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			try { camera.CaptureImage(); }
			catch (Exception ex) { Dispatcher.BeginInvoke(() => MessageBox.Show(ex.Message)); }
		}

		void camera_CaptureImageAvailable(object sender, ContentReadyEventArgs e)
		{
			Dispatcher.BeginInvoke(() => ThreadSafeImageCapture(e));
		}

		void ThreadSafeImageCapture(ContentReadyEventArgs e)
		{
			library.SavePictureToCameraRoll(DateTime.Now.ToString() + ".jpg", e.ImageStream);
}

		void CameraButtons_ShutterKeyReleased(object sender, EventArgs e)
		{
			if (camera != null)
				camera.CancelFocus();
		}

		void CameraButtons_ShutterKeyPressed(object sender, EventArgs e)
		{
			if (camera != null)
			{
				try { camera.CaptureImage(); }
				catch (Exception ex) { Dispatcher.BeginInvoke(() => MessageBox.Show(ex.Message)); }
			}
		}

		void CameraButtons_ShutterKeyHalfPressed(object sender, EventArgs e)
		{
			if (camera != null)
			{
				try { camera.Focus(); }
				catch (Exception ex) { }
			}
		}
	}
}