﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;

namespace PhoneApp2
{
    public partial class MainPage : PhoneApplicationPage
    {
        private string _book;

        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // We need to wait until loaded before checking NavigationContext
            Loaded += HandleLoaded;
        }

        private void HandleLoaded(object sender, RoutedEventArgs e)
        {
            // Determine what the context of the app launch is
            if (NavigationContext.QueryString.ContainsKey("ProductName"))
            {
                _book = NavigationContext.QueryString["ProductName"];
                lblPageTitle.Text = "Book Details";
            }
            else if (NavigationContext.QueryString.ContainsKey("bing_query"))
            {
                _book = NavigationContext.QueryString["bing_query"];
                lblPageTitle.Text = "Related Search";
            }
            else
            {
                _book = null;
            }

            // In a "real" application we'd want to use binding and converters
            if (!string.IsNullOrWhiteSpace(_book))
            {
                lblBookTitle.Text = _book;
                lblNoSearch.Visibility = Visibility.Collapsed;
                lblBookTitle.Visibility = Visibility.Visible;
            }
            else
            {
                lblNoSearch.Visibility = Visibility.Visible;
                lblBookTitle.Visibility = Visibility.Collapsed;
            }
        }

        private void HandleSearchBarnesAndNoble(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_book))
            {
                BrowseTo("http://www.barnesandnoble.com/ebooks/index.asp");
            }
            else
            {
                BrowseTo("http://productsearch.barnesandnoble.com/search/results.aspx?store=BOOK&keyword=\"" + _book.Replace(" ", "+") + "\"");
            }
        }

        private void HandleSearchAmazonBooks(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_book))
            {
                BrowseTo("http://www.amazon.com/gp/aw/sb.html/sn=Books");
            }
            else
            {
                BrowseTo("http://www.amazon.com/gp/aw/s/?k=" + _book.Replace(" ", "+"));
            }
        }

        private static void BrowseTo(string address)
        {
            var webTask = new Microsoft.Phone.Tasks.WebBrowserTask();
            webTask.Uri = new Uri(address);
            webTask.Show();
        }

    }
}