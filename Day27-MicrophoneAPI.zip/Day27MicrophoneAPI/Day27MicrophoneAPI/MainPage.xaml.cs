﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using Microsoft.Phone.Controls;
using Microsoft.Xna.Framework.Audio;
using System.IO;
using System.Windows.Threading;
using System.Threading;
using Microsoft.Xna.Framework;
using System.Windows.Media.Imaging;

namespace Day27MicrophoneAPI
{
    public partial class MainPage : PhoneApplicationPage
    {
        //Microphone.Default returns the default attached microphone
        private Microphone microphone = Microphone.Default;
        private MemoryStream stream = new MemoryStream();
        private SoundEffectInstance recordedSound;
        private byte[] buffer;
        bool isSoundPlaying = false;//used to indicate whether the sound is currently playing
        string microphoneStoppedImagePath = "images/stopped.png";
        string microphoneStartedImagePath = "images/114px-Yeti-USB-Microphone.png";
        string lightPlayButtonPausedImagePath = "images/light.appbar.transport.pause.rest.png";
        string darkPlayButtonPausedImagePath = "images/dark.appbar.transport.pause.rest.png";
        string lightPlayButtonImagePath = "images/light.appbar.transport.play.rest.png";
        string darkPlayButtonImagePath = "images/dark.appbar.transport.play.rest.png";
        bool recordingStopped = false;
        bool playSound = false;// used to trigger sound playback
        bool streamFlushed = false; //used to indicate if the microphone buffer has been flushed
        bool isDarkTheme = ((Visibility)Application.Current.Resources["PhoneDarkThemeVisibility"] == Visibility.Visible);

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            // Timer to simulate the XNA Framework game loop (Microphone is 
            // from the XNA Framework). We also use this timer to monitor the 
            // state of audio playback so we can update the UI appropriately.
            DispatcherTimer dt = new DispatcherTimer();
            dt.Interval = TimeSpan.FromMilliseconds(33);
            dt.Tick += new EventHandler(dt_Tick);
            dt.Start();
            //Setup the microphone
            SetupMicrophone();
            SoundEffect.MasterVolume = 1.0f;
            SetThemeBasedImageBackgroundforPlayIcon();
        }


        /// <summary>
        /// Updates the XNA FrameworkDispatcher and checks to see if a sound is playing.
        /// If sound has stopped playing, it updates the UI.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dt_Tick(object sender, EventArgs e)
        {
            try { FrameworkDispatcher.Update(); }
            catch(Exception ex) 
            {
                throw ex;
            }

            if (true == isSoundPlaying)
            {
                if (recordedSound.State != SoundState.Playing)
                {
                    ResetPlaybackSettings();
                }
            }
            else
            {
                //We handle the playback in the tick event as we need to capture the last bit of recorded data
                //before starting playback. This avoids the microphone data from being cut off.
                //The streamFlushed boolean is set to true when the last buffer data is released from the microphone
                if (playSound && streamFlushed)
                {
                    playSound = false;
                    if (stream.Length > 0)
                    {
                        SetThemeBasedImageBackgroundForPauseIcon();
                        // Play the audio in a new thread so the UI can update.
                        Thread soundThread = new Thread(new ThreadStart(startPlayBack));
                        soundThread.Start();
                    }
                }
            }
        }

        /// <summary>
        /// Common code that is executed when playback stops after playing the entire
        /// sound or by user action.
        /// </summary>
        private void ResetPlaybackSettings()
        {
            // Audio has finished playing
            isSoundPlaying = false;

            // Update the UI to reflect that the 
            // sound has stopped playing
            // Can update screen background etc here
            SetThemeBasedImageBackgroundforPlayIcon();
            playSound=false;
        }

        /// <summary>
        /// This method is called when the microphone buffer is full
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void microphone_BufferReady(object sender, EventArgs e)
        {
            //Retrieve audio data by calling GetData()
            microphone.GetData(buffer);
            stream.Write(buffer, 0, buffer.Length);

            if (recordingStopped)
            {
                //User stopped recording
                stream.Flush();
                streamFlushed = true;
                microphone.Stop();
            }
        }


        /// <summary>
        /// Set up microphone with defaults and background image
        /// </summary>
        private void SetupMicrophone()
        {
            // No microphone connected?
            if (Microphone.Default == null)
            {
                return;
            }

            // Get audio data in 1/2 second chunks.
            microphone.BufferDuration = TimeSpan.FromMilliseconds(500);
            // Allocate memory to hold the audio data
            buffer = new byte[microphone.GetSampleSizeInBytes(microphone.BufferDuration)];

            // Set the stream back to zero in case there is already something in it.
            stream.SetLength(0);

            // Subscribe to the BufferReady event.
            microphone.BufferReady += new EventHandler<EventArgs>(microphone_BufferReady);

            //Set image background of the microphone button to indicate that the recording is stopped.
            ImageBrush brush = new ImageBrush();
            brush.ImageSource = new BitmapImage(new Uri(microphoneStoppedImagePath, UriKind.Relative));
            brush.Stretch = Stretch.Uniform;
            recordButton.Background = brush;
        }

        /// <summary>
        /// Handles the touch event for the Microphone
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void recordButton_Click(object sender, RoutedEventArgs e)
        {
            if (isSoundPlaying) 
            {
                return;
            }
            streamFlushed = false;
            //Change microphone image to indicate to the user that the microphone is started or stopped.
            //Also clear the stream when we start the microphone so we only record the new sound.
            if (microphone.State == MicrophoneState.Stopped)
            {
                ImageBrush brush = new ImageBrush();
                brush.ImageSource = new BitmapImage(new Uri(microphoneStartedImagePath, UriKind.Relative));
                brush.Stretch = Stretch.Uniform;
                recordButton.Background = brush;
                if (recordedSound != null) recordedSound.Stop();
                stream.SetLength(0);
                recordingStopped = false;
                microphone.Start();

            }
            else if (microphone.State == MicrophoneState.Started)
            {
                //flushMicrophoneBufferData();
                recordingStopped = true;
                ImageBrush brush = new ImageBrush();
                brush.ImageSource = new BitmapImage(new Uri(microphoneStoppedImagePath, UriKind.Relative));
                brush.Stretch = Stretch.Uniform;
                recordButton.Background = brush;
                playButton.IsEnabled = true;
            }

            playSound = false;
            SetThemeBasedImageBackgroundforPlayIcon();
            isSoundPlaying = false;
           
            
        }

        /// <summary>
        /// Handles the touch event for the playbutton.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void playButton_Click(object sender, RoutedEventArgs e)
        {
            if (isSoundPlaying == false)
            {
                //Change microphone image to indicate to the user that the microphone is
                //not recording.
                if (microphone.State == MicrophoneState.Started)
                {
                    ImageBrush brush = new ImageBrush();
                    brush.ImageSource = new BitmapImage(new Uri(microphoneStoppedImagePath, UriKind.Relative));
                    brush.Stretch = Stretch.Uniform;
                    recordButton.Background = brush;
                    recordingStopped = true;
                    
                }
                playSound = true;
            }
            else
            {
                ResetPlaybackSettings();
            }

    
        }

        /// <summary>
        /// This subroutine plays back the recorded audio and is called on a different thread than the UI
        /// thread.
        /// </summary>
        private void startPlayBack()
        {
            // Play audio using SoundEffectInstance so we can monitor it's State 
            // and update the UI in the dt_Tick handler when it is done playing.
            SoundEffect sound = new SoundEffect(stream.ToArray(), microphone.SampleRate, AudioChannels.Mono);
            recordedSound = sound.CreateInstance();
            
            isSoundPlaying = true;
            //Use the dispatcher class to access the slider values from the UI thread.
            Dispatcher.BeginInvoke(
            () =>
            {
                recordedSound.Pitch = (float)pitchSlider.Value;
                recordedSound.Pan = (float)panSlider.Value;
                recordedSound.Volume = (float)volumeSlider.Value;
            }
            );
            recordedSound.Play();
        }

        /// <summary>
        /// Toggles the play icon based on the theme
        /// </summary>
        private void SetThemeBasedImageBackgroundforPlayIcon()
        {
            ImageBrush brush2 = new ImageBrush();
            if (isDarkTheme)
            {
                brush2.ImageSource = new BitmapImage(new Uri(darkPlayButtonImagePath, UriKind.Relative));
            }
            else
            {
                brush2.ImageSource = new BitmapImage(new Uri(lightPlayButtonImagePath, UriKind.Relative));
            }
            brush2.Stretch = Stretch.Uniform;
            playButton.Background = brush2;
        }

         
        
        /// <summary>
        /// Toggles the pause icon based on the theme
        /// </summary>
        private void SetThemeBasedImageBackgroundForPauseIcon()
        {
            ImageBrush brush = new ImageBrush();
            if (isDarkTheme)
            {
                brush.ImageSource = new BitmapImage(new Uri(darkPlayButtonPausedImagePath, UriKind.Relative));
            }
            else
            {
                brush.ImageSource = new BitmapImage(new Uri(lightPlayButtonPausedImagePath, UriKind.Relative));
            }
            brush.Stretch = Stretch.Uniform;
            playButton.Background = brush;
        }

    }
}