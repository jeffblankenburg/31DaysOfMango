﻿Note: The images used in this application have been taken from Wikipedia and are licensed under the 
Creative Commons Attribution-Share Alike 3.0 Unported license and under the 
Creative Commons CC0 1.0 Universal Public Domain Dedication.
