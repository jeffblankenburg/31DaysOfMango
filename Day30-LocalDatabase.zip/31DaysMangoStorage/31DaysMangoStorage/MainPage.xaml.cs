﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Phone.Controls;

using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace _31DaysMangoStorage
{
    public partial class MainPage : PhoneApplicationPage, INotifyPropertyChanged
    {
        // Data context for the local database
        private IdeaDataContext ideaDB;

        // Define an observable collection property that controls can bind to.
        private ObservableCollection<IdeaItem> _ideaItems;
        public ObservableCollection<IdeaItem> IdeaItems
        {
            get
            {
                return _ideaItems;
            }
            set
            {
                if (_ideaItems != value)
                {
                    _ideaItems = value;
                    NotifyPropertyChanged("IdeaItems");
                }
            }
        }

        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Connect to the database and instantiate data context.
            ideaDB = new IdeaDataContext(IdeaDataContext.DBConnectionString);

            // Data context and observable collection are children of the main page.
            this.DataContext = this;
        }


        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        // Used to notify Silverlight that a property has changed.
        private void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            // Define the query to gather all of the idea items.
            var ideaItemsInDB = from IdeaItem idea in ideaDB.IdeaItems
                                select idea;

            // Execute the query and place the results into a collection.
            IdeaItems = new ObservableCollection<IdeaItem>(ideaItemsInDB);

            // Call the base method.
            base.OnNavigatedTo(e);
        }

        private void newIdeaTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            // Clear the text box when it gets focus.
            newIdeaTextBox.Text = String.Empty;
        }

        private void newIdeaAddButton_Click(object sender, RoutedEventArgs e)
        {
            // Create a new idea item based on the text box.
            IdeaItem newIdea = new IdeaItem { ItemName = newIdeaTextBox.Text };

            // Add a idea item to the observable collection.
            IdeaItems.Add(newIdea);

            // Add a idea item to the local database.
            ideaDB.IdeaItems.InsertOnSubmit(newIdea);
        }

        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            // Call the base method.
            base.OnNavigatedFrom(e);

            // Save changes to the database.
            ideaDB.SubmitChanges();
        }

        private void deleteIdeaButton_Click(object sender, RoutedEventArgs e)
        {
            // Cast parameter as a button.
            var button = sender as Button;

            if (button != null)
            {
                // Get a handle for the idea item bound to the button.
                IdeaItem ideaForDelete = button.DataContext as IdeaItem;

                // Remove the idea item from the observable collection.
                IdeaItems.Remove(ideaForDelete);

                // Remove the idea item from the local database.
                ideaDB.IdeaItems.DeleteOnSubmit(ideaForDelete);

                // Save changes to the database.
                ideaDB.SubmitChanges();

                // Put the focus back to the main page.
                this.Focus();
            }
        }
    }

    public class IdeaDataContext : DataContext
    {
        // Specify the connection string as a static, used in main page and app.xaml.
        public static string DBConnectionString = "Data Source=isostore:/Ideas.sdf";

        // Pass the connection string to the base class.
        public IdeaDataContext(string connectionString)
            : base(connectionString)
        { }

        // Specify a single table for the idea items.
        public Table<IdeaItem> IdeaItems;
    }

    [Table]
    public class IdeaItem : INotifyPropertyChanged, INotifyPropertyChanging
    {
    // Define ID: private field, public property and database column.
    private int _ideaItemId;

    [Column(IsPrimaryKey = true, IsDbGenerated = true, DbType = "INT NOT NULL Identity", CanBeNull = false, AutoSync = AutoSync.OnInsert)]
    public int IdeaItemId
    {
        get
        {
            return _ideaItemId;
        }
        set
        {
            if (_ideaItemId != value)
            {
                NotifyPropertyChanging("IdeaItemId");
                _ideaItemId = value;
                NotifyPropertyChanged("IdeaItemId");
            }
        }
    }

    // Define item name: private field, public property and database column.
    private string _itemName;

    [Column]
    public string ItemName
    {
        get
        {
            return _itemName;
        }
        set
        {
            if (_itemName != value)
            {
                NotifyPropertyChanging("ItemName");
                _itemName = value;
                NotifyPropertyChanged("ItemName");
            }
        }
    }

    // Define completion value: private field, public property and database column.
    private bool _isComplete;

    [Column]
    public bool IsComplete
    {
        get
        {
            return _isComplete;
        }
        set
        {
            if (_isComplete != value)
            {
                NotifyPropertyChanging("IsComplete");
                _isComplete = value;
                NotifyPropertyChanged("IsComplete");
            }
        }
    }
    // Version column aids update performance.
    [Column(IsVersion = true)]
    private Binary _version;

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    // Used to notify the page that a data context property changed
    private void NotifyPropertyChanged(string propertyName)
    {
        if (PropertyChanged != null)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    #endregion

    #region INotifyPropertyChanging Members

    public event PropertyChangingEventHandler PropertyChanging;

    // Used to notify the data context that a data context property is about to change
    private void NotifyPropertyChanging(string propertyName)
    {
        if (PropertyChanging != null)
        {
            PropertyChanging(this, new PropertyChangingEventArgs(propertyName));
        }
    }

    #endregion
    }
}