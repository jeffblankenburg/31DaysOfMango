﻿using System.Windows;
using Microsoft.Phone.Controls;
using ControlTiltEffect;

namespace Day19_TiltEffects
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            bool tiltEnabled = TiltEffect.GetIsTiltEnabled(this);
            ToggleTilting.Content = (tiltEnabled) ? "Start Tilts" : "Stop Tilts";
            TiltEffect.SetIsTiltEnabled(this, !tiltEnabled);
        }
    }
}